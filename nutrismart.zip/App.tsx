import React, { useState, useEffect } from 'react';
import { Menu } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import AiAssistant from './pages/AiAssistant';
import RegisterMeal from './pages/RegisterMeal';
import RegisterExercise from './pages/RegisterExercise';
import Recipes from './pages/Recipes';
import Planning from './pages/Planning';
import Progress from './pages/Progress';
import Awards from './pages/Awards';
import Notifications from './pages/Notifications';
import Plans from './pages/Plans';
import Profile from './pages/Profile';
import { NavItem, User, DailyStats, Meal, Exercise } from './types';
import { checkAchievements } from './services/gamificationService';

// Initial Mock Data
const INITIAL_USER: User = {
  name: 'Fabricio Souza',
  email: 'fabricio@example.com',
  dailyCalorieGoal: 2355,
  dailyWaterGoal: 3000,
  weight: 75.5,
  height: 180,
  age: 28,
  macros: {
    protein: 142,
    carbs: 301,
    fats: 65
  }
};

const AppLayout: React.FC<{ children: React.ReactNode; currentPath: NavItem; onNavigate: (item: NavItem) => void }> = ({ children, currentPath, onNavigate }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar 
        activeItem={currentPath} 
        onNavigate={onNavigate} 
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
      />
      
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen transition-all duration-300">
        <div className="lg:hidden p-4 bg-white border-b border-gray-200 flex items-center justify-between sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-nutri-500 to-nutri-600 rounded-lg flex items-center justify-center text-white">
              <span className="font-bold text-xs">NS</span>
            </div>
            <span className="font-bold text-gray-800">NutriSmart</span>
          </div>
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 text-gray-600 hover:bg-gray-100 rounded-md">
            <Menu size={24} />
          </button>
        </div>

        <main className="flex-1">
          {children}
        </main>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [activeItem, setActiveItem] = useState<NavItem>(NavItem.Dashboard);
  const [isLoaded, setIsLoaded] = useState(false);
  
  // GLOBAL STATE
  const [user, setUser] = useState<User>(INITIAL_USER);
  const [waterConsumed, setWaterConsumed] = useState(0);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>([]);
  
  // Load from LocalStorage on mount
  useEffect(() => {
    const loadData = () => {
      try {
        const savedUser = localStorage.getItem('nutrismart_user');
        const savedWater = localStorage.getItem('nutrismart_water');
        const savedMeals = localStorage.getItem('nutrismart_meals');
        const savedExercises = localStorage.getItem('nutrismart_exercises');
        const savedAchievements = localStorage.getItem('nutrismart_achievements');

        if (savedUser) setUser(JSON.parse(savedUser));
        if (savedWater) setWaterConsumed(Number(savedWater));
        if (savedMeals) setMeals(JSON.parse(savedMeals));
        if (savedExercises) setExercises(JSON.parse(savedExercises));
        if (savedAchievements) setUnlockedAchievements(JSON.parse(savedAchievements));
      } catch (e) {
        console.error("Failed to load local storage", e);
      } finally {
        setIsLoaded(true);
      }
    };
    loadData();
  }, []);

  // Save to LocalStorage on change
  useEffect(() => {
    if (!isLoaded) return;
    localStorage.setItem('nutrismart_user', JSON.stringify(user));
    localStorage.setItem('nutrismart_water', waterConsumed.toString());
    localStorage.setItem('nutrismart_meals', JSON.stringify(meals));
    localStorage.setItem('nutrismart_exercises', JSON.stringify(exercises));
    localStorage.setItem('nutrismart_achievements', JSON.stringify(unlockedAchievements));
  }, [user, waterConsumed, meals, exercises, unlockedAchievements, isLoaded]);

  // Derived State (Calculated automatically)
  const [stats, setStats] = useState<DailyStats>({
    caloriesConsumed: 0,
    caloriesBurned: 0,
    proteinConsumed: 0,
    carbsConsumed: 0,
    fatsConsumed: 0,
    waterConsumed: 0
  });

  // Calculate stats whenever meals, exercises or water changes
  useEffect(() => {
    const newStats: DailyStats = {
      caloriesConsumed: meals.reduce((acc, meal) => acc + meal.calories, 0),
      caloriesBurned: exercises.reduce((acc, ex) => acc + ex.caloriesBurned, 0),
      proteinConsumed: meals.reduce((acc, meal) => acc + meal.macros.protein, 0),
      carbsConsumed: meals.reduce((acc, meal) => acc + meal.macros.carbs, 0),
      fatsConsumed: meals.reduce((acc, meal) => acc + meal.macros.fats, 0),
      waterConsumed: waterConsumed
    };
    setStats(newStats);

    // CHECK GAMIFICATION
    if (isLoaded) {
      const newUnlocked = checkAchievements(user, newStats, meals, exercises, unlockedAchievements);
      if (newUnlocked.length > unlockedAchievements.length) {
        // Simple alert for now, could be a toast in the future
        // We only alert if it's a new unlock that wasn't there before mount
        const diff = newUnlocked.filter(x => !unlockedAchievements.includes(x));
        if (diff.length > 0) {
           // Optional: alert(`Nova conquista desbloqueada!`);
        }
        setUnlockedAchievements(newUnlocked);
      }
    }
  }, [meals, exercises, waterConsumed, isLoaded]);

  // Handlers
  const handleUpdateWater = (amount: number) => {
    setWaterConsumed(prev => Math.max(0, prev + amount));
  };

  const handleAddMeal = (newMeal: Omit<Meal, 'id'>) => {
    const meal: Meal = {
      ...newMeal,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };
    setMeals(prev => [meal, ...prev]);
    setActiveItem(NavItem.Dashboard); // Redirect to dashboard to see changes
  };

  const handleUpdateMeal = (updatedMeal: Meal) => {
    setMeals(prev => prev.map(meal => meal.id === updatedMeal.id ? updatedMeal : meal));
    alert("Refeição atualizada com sucesso!");
    setActiveItem(NavItem.Dashboard);
  };

  const handleAddExercise = (newExercise: Omit<Exercise, 'id'>) => {
    const exercise: Exercise = {
      ...newExercise,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };
    setExercises(prev => [exercise, ...prev]);
    setActiveItem(NavItem.Dashboard); // Redirect to dashboard
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
    alert("Perfil atualizado com sucesso!");
    setActiveItem(NavItem.Dashboard);
  };

  const renderContent = () => {
    switch (activeItem) {
      case NavItem.Dashboard:
        return (
          <Dashboard 
            user={user} 
            stats={stats} 
            updateWater={handleUpdateWater} 
            recentMeals={meals.slice(0, 3)} // Show only 3 most recent
            recentExercises={exercises.slice(0, 3)}
            onNavigate={setActiveItem}
          />
        );
      case NavItem.RegisterMeal:
        return <RegisterMeal onSave={handleAddMeal} onUpdate={handleUpdateMeal} history={meals} />;
      case NavItem.RegisterExercise:
        return <RegisterExercise user={user} onSave={handleAddExercise} />;
      case NavItem.Recipes:
        return <Recipes />;
      case NavItem.Planning:
        return <Planning user={user} />;
      case NavItem.Progress:
        return <Progress weightHistory={[{ day: 'Hoje', weight: user.weight || 0 }]} />;
      case NavItem.Assistant:
        return <AiAssistant user={user} stats={stats} recentMeals={meals} />;
      case NavItem.Awards:
        return <Awards unlockedIds={unlockedAchievements} />;
      case NavItem.Notifications:
        return <Notifications />;
      case NavItem.Plans:
        return <Plans />;
      case NavItem.Profile:
        return <Profile user={user} onUpdate={handleUpdateUser} />;
      default:
        return <Dashboard user={user} stats={stats} updateWater={handleUpdateWater} recentMeals={meals} recentExercises={exercises} onNavigate={setActiveItem} />;
    }
  };

  return (
    <AppLayout currentPath={activeItem} onNavigate={setActiveItem}>
      {renderContent()}
    </AppLayout>
  );
};

export default App;
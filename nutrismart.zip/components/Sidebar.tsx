import React from 'react';
import { 
  LayoutDashboard, 
  Utensils, 
  Dumbbell, 
  ChefHat, 
  CalendarDays, 
  TrendingUp, 
  Sparkles, 
  Trophy, 
  Bell, 
  CreditCard, 
  User, 
  LogOut 
} from 'lucide-react';
import { NavItem } from '../types';

interface SidebarProps {
  activeItem: NavItem;
  onNavigate: (item: NavItem) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeItem, onNavigate, isOpen, setIsOpen }) => {
  
  const menuItems = [
    { id: NavItem.Dashboard, icon: LayoutDashboard, label: 'Dashboard' },
    { id: NavItem.RegisterMeal, icon: Utensils, label: 'Registrar Refeição' },
    { id: NavItem.RegisterExercise, icon: Dumbbell, label: 'Registrar Exercício' },
    { id: NavItem.Recipes, icon: ChefHat, label: 'Receitas' },
    { id: NavItem.Planning, icon: CalendarDays, label: 'Planejamento' },
    { id: NavItem.Progress, icon: TrendingUp, label: 'Progresso' },
    { id: NavItem.Assistant, icon: Sparkles, label: 'Assistente IA' },
    { id: NavItem.Awards, icon: Trophy, label: 'Conquistas' },
    { id: NavItem.Notifications, icon: Bell, label: 'Notificações' },
    { id: NavItem.Plans, icon: CreditCard, label: 'Planos e Assinatura' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 bg-black/50 z-20 lg:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsOpen(false)}
      />

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 z-30 h-screen w-64 bg-white border-r border-gray-200 transition-transform duration-300 transform lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white bg-gradient-to-br from-nutri-500 to-nutri-600 shadow-sm">
              <Sparkles size={18} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800 leading-none">NutriSmart</h1>
              <p className="text-xs text-gray-500">Sua saúde em primeiro lugar</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeItem === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive 
                      ? 'bg-gradient-to-r from-nutri-500 to-nutri-600 text-white shadow-md shadow-nutri-200' 
                      : 'text-gray-600 hover:bg-nutri-50 hover:text-nutri-600'
                  }`}
                >
                  <Icon size={20} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* User Profile Footer */}
          <div className="p-4 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center gap-3 mb-3 cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition" onClick={() => onNavigate(NavItem.Profile)}>
              <img 
                src="https://picsum.photos/100/100" 
                alt="User" 
                className="w-10 h-10 rounded-full object-cover border-2 border-nutri-500 p-0.5" 
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">Fabricio Souza</p>
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-nutri-500"></span>
                  <p className="text-xs text-gray-500">Online</p>
                </div>
              </div>
            </div>
            
            <button 
              onClick={() => onNavigate(NavItem.Profile)}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md mb-1 transition-colors"
            >
              <User size={16} />
              Meu Perfil
            </button>
            <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-transparent hover:border-red-100 transition-colors">
              <LogOut size={16} />
              Sair
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
import React from 'react';
import { Trophy, Medal, Award, Star, Flame, Droplet, Calendar, ChefHat } from 'lucide-react';
import { ACHIEVEMENT_DEFINITIONS } from '../services/gamificationService';

interface AwardsProps {
  unlockedIds?: string[];
}

const Awards: React.FC<AwardsProps> = ({ unlockedIds = [] }) => {
  const getIcon = (name: string, unlocked: boolean) => {
    const props = { size: 32, className: unlocked ? 'text-yellow-500' : 'text-gray-300' };
    switch(name) {
      case 'Star': return <Star {...props} fill={unlocked ? 'currentColor' : 'none'} />;
      case 'Droplet': return <Droplet {...props} fill={unlocked ? 'currentColor' : 'none'} />;
      case 'Flame': return <Flame {...props} fill={unlocked ? 'currentColor' : 'none'} />;
      case 'Calendar': return <Calendar {...props} />;
      case 'Trophy': return <Trophy {...props} fill={unlocked ? 'currentColor' : 'none'} />;
      case 'ChefHat': return <ChefHat {...props} />;
      default: return <Award {...props} />;
    }
  };

  // Merge definitions with current unlocked status
  const achievements = ACHIEVEMENT_DEFINITIONS.map(def => ({
    ...def,
    unlocked: unlockedIds.includes(def.id)
  }));

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;
  const progressPercent = Math.round((unlockedCount / totalCount) * 100);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Suas Conquistas</h1>
        <p className="text-gray-500 mb-6">Desbloqueie medalhas mantendo hábitos saudáveis!</p>
        
        {/* Progress Bar */}
        <div className="max-w-md mx-auto">
          <div className="flex justify-between text-xs font-semibold text-gray-500 mb-2">
            <span>Nível Atual</span>
            <span>{unlockedCount} / {totalCount} Desbloqueadas</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full transition-all duration-1000"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => (
          <div 
            key={achievement.id} 
            className={`relative p-6 rounded-2xl border transition-all duration-300 flex items-center gap-4 group ${
              achievement.unlocked 
                ? 'bg-white border-yellow-200 shadow-sm hover:shadow-md hover:border-yellow-300 transform hover:-translate-y-1' 
                : 'bg-gray-50 border-gray-100 opacity-70 grayscale hover:grayscale-0 hover:opacity-100'
            }`}
          >
            <div className={`w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 transition-colors duration-300 ${
              achievement.unlocked ? 'bg-yellow-50 shadow-inner' : 'bg-gray-200 group-hover:bg-gray-100'
            }`}>
              {getIcon(achievement.iconName, achievement.unlocked)}
            </div>
            
            <div>
              <h3 className={`font-bold mb-1 ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                {achievement.title}
              </h3>
              <p className="text-xs text-gray-500 leading-tight">
                {achievement.description}
              </p>
            </div>

            {achievement.unlocked ? (
              <div className="absolute top-3 right-3 text-yellow-500 animate-fade-in">
                <Medal size={16} />
              </div>
            ) : (
              <div className="absolute top-3 right-3 text-gray-300">
                <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Awards;
import React, { useState } from 'react';
import { 
  Plus, 
  Minus, 
  Camera, 
  Dumbbell, 
  Utensils, 
  Calendar, 
  MessageCircle, 
  Droplet,
  Clock,
  Flame,
  ChevronRight
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { DailyStats, User, Meal, Exercise, NavItem } from '../types';

interface DashboardProps {
  user: User;
  stats: DailyStats;
  updateWater: (amount: number) => void;
  recentMeals: Meal[];
  recentExercises: Exercise[];
  onNavigate: (item: NavItem) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, stats, updateWater, recentMeals, recentExercises, onNavigate }) => {
  const [weight, setWeight] = useState<string>('');

  // Derived calculations
  const remainingCalories = Math.max(0, user.dailyCalorieGoal - stats.caloriesConsumed + stats.caloriesBurned);
  const progressPercentage = Math.min(100, Math.round((stats.caloriesConsumed / user.dailyCalorieGoal) * 100));
  
  // Chart Data
  const data = [
    { name: 'Consumed', value: stats.caloriesConsumed },
    { name: 'Remaining', value: remainingCalories },
  ];
  
  const COLORS = ['#00b37e', '#f3f4f6'];

  const currentDate = new Date().toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Olá, {user.name.split(' ')[0]}</h1>
          <p className="text-gray-500 capitalize">{currentDate}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate(NavItem.Assistant)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-nutri-500 text-nutri-500 rounded-lg hover:bg-nutri-50 font-medium shadow-sm transition"
          >
            <MessageCircle size={18} /> Assistente
          </button>
          <button 
             onClick={() => onNavigate(NavItem.Progress)}
            className="flex items-center gap-2 px-4 py-2 bg-nutri-600 text-white rounded-lg hover:bg-nutri-700 font-medium shadow-md transition-all duration-300"
          >
            <PieChart size={18} className="w-5 h-5" /> Análise
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Calorie Summary Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 lg:col-span-1">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Resumo Calórico</h2>
          
          <div className="flex justify-between text-center mb-6">
            <div>
              <p className="text-sm text-gray-500">Consumidas</p>
              <p className="text-2xl font-bold text-gray-900">{stats.caloriesConsumed}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Gastas</p>
              <p className="text-2xl font-bold text-gray-900">{stats.caloriesBurned}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Disponíveis</p>
              <p className="text-2xl font-bold text-nutri-600">{remainingCalories}</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
             {/* Macros */}
            <div className="flex-1 space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Proteínas</span>
                  <span className="text-gray-900 font-medium">{stats.proteinConsumed}g / {user.macros.protein}g</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full" style={{ width: `${Math.min(100, (stats.proteinConsumed/user.macros.protein)*100)}%` }}></div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Carboidratos</span>
                  <span className="text-gray-900 font-medium">{stats.carbsConsumed}g / {user.macros.carbs}g</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full" style={{ width: `${Math.min(100, (stats.carbsConsumed/user.macros.carbs)*100)}%` }}></div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Gorduras</span>
                  <span className="text-gray-900 font-medium">{stats.fatsConsumed}g / {user.macros.fats}g</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-red-400 to-red-600 rounded-full" style={{ width: `${Math.min(100, (stats.fatsConsumed/user.macros.fats)*100)}%` }}></div>
                </div>
              </div>
            </div>

             {/* Chart */}
             <div className="relative w-32 h-32 flex-shrink-0">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={data}
                     cx="50%"
                     cy="50%"
                     innerRadius={40}
                     outerRadius={55}
                     startAngle={90}
                     endAngle={-270}
                     dataKey="value"
                     stroke="none"
                   >
                     {data.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                     ))}
                   </Pie>
                 </PieChart>
               </ResponsiveContainer>
               <div className="absolute inset-0 flex flex-col items-center justify-center">
                 <span className="text-lg font-bold text-gray-900">{progressPercentage}%</span>
                 <span className="text-[10px] text-gray-500">da meta</span>
               </div>
             </div>
          </div>
          {remainingCalories < 0 && (
            <div className="mt-4 flex justify-center">
              <span className="bg-red-50 text-red-600 border border-red-100 text-xs font-semibold px-3 py-1 rounded-full">Meta Excedida</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => onNavigate(NavItem.RegisterMeal)}
            className="bg-gradient-to-br from-nutri-500 to-nutri-600 hover:from-nutri-500 hover:to-nutri-700 transition-all duration-300 rounded-2xl p-6 flex flex-col items-center justify-center text-white shadow-lg shadow-nutri-200 group h-64 md:h-auto border border-transparent hover:scale-[1.01]"
          >
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-inner">
              <Camera size={32} />
            </div>
            <span className="text-xl font-bold">Registrar Refeição</span>
          </button>
          
          <button 
            onClick={() => onNavigate(NavItem.RegisterExercise)}
            className="bg-gradient-to-br from-nutri-500 to-nutri-600 hover:from-nutri-500 hover:to-nutri-700 transition-all duration-300 rounded-2xl p-6 flex flex-col items-center justify-center text-white shadow-lg shadow-nutri-200 group h-64 md:h-auto border border-transparent hover:scale-[1.01]"
          >
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-inner">
              <Dumbbell size={32} />
            </div>
            <span className="text-xl font-bold">Registrar Exercício</span>
          </button>
        </div>
      </div>

      {/* Quick Links Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div onClick={() => onNavigate(NavItem.Recipes)} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 hover:shadow-md transition cursor-pointer group">
          <div className="w-12 h-12 bg-nutri-50 text-nutri-500 rounded-lg flex items-center justify-center group-hover:bg-nutri-100 transition-colors">
            <Utensils size={24} />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Receitas Saudáveis</h3>
            <p className="text-xs text-gray-500">Computar receitas saudáveis</p>
          </div>
        </div>
        <div onClick={() => onNavigate(NavItem.Planning)} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 hover:shadow-md transition cursor-pointer group">
          <div className="w-12 h-12 bg-nutri-50 text-nutri-500 rounded-lg flex items-center justify-center group-hover:bg-nutri-100 transition-colors">
            <Calendar size={24} />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Plano de Refeições</h3>
            <p className="text-xs text-gray-500">Completar o plano de meal plan</p>
          </div>
        </div>
        <div onClick={() => onNavigate(NavItem.Assistant)} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 hover:shadow-md transition cursor-pointer group">
          <div className="w-12 h-12 bg-nutri-50 text-nutri-500 rounded-lg flex items-center justify-center group-hover:bg-nutri-100 transition-colors">
            <MessageCircle size={24} />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Assistente Nutricional</h3>
            <p className="text-xs text-gray-500">Combinar assistente nutricional</p>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Recent Meals */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 min-h-[250px] overflow-y-auto">
          <div className="flex justify-between items-center mb-4">
             <h3 className="font-bold text-gray-900">Refeições Recentes</h3>
             <button onClick={() => onNavigate(NavItem.RegisterMeal)} className="text-nutri-600 text-xs hover:underline">Ver todas</button>
          </div>
          
          {recentMeals.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-gray-400 text-sm">
              <Utensils size={32} className="mb-2 opacity-50" />
              Nenhuma refeição hoje
            </div>
          ) : (
            <div className="space-y-3">
              {recentMeals.map((meal, idx) => (
                <div key={meal.id + idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-nutri-50 transition">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-xl">
                      {meal.type === 'breakfast' ? '☕' : meal.type === 'lunch' ? '🥗' : meal.type === 'dinner' ? '🍲' : '🍎'}
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-gray-900 line-clamp-1">{meal.name}</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1"><Clock size={10} /> {meal.time}</p>
                    </div>
                  </div>
                  <span className="font-bold text-sm text-nutri-600">{meal.calories} kcal</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Exercises */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 min-h-[250px] overflow-y-auto">
          <div className="flex justify-between items-center mb-4">
             <h3 className="font-bold text-gray-900">Exercícios Recentes</h3>
             <button onClick={() => onNavigate(NavItem.RegisterExercise)} className="text-nutri-600 text-xs hover:underline">Ver todos</button>
          </div>

          {recentExercises.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-gray-400 text-sm">
              <Dumbbell size={32} className="mb-2 opacity-50" />
              Nenhum exercício hoje
            </div>
          ) : (
            <div className="space-y-3">
              {recentExercises.map((ex, idx) => (
                <div key={ex.id + idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-nutri-50 transition">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-nutri-500">
                      <Dumbbell size={20} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-gray-900 line-clamp-1">{ex.name}</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1">{ex.durationMinutes} min</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-sm text-orange-500">-{ex.caloriesBurned}</span>
                    <p className="text-[10px] text-gray-400">kcal</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Weight Registration */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-4">Registro de Peso</h3>
          <div className="space-y-4">
             <div className="flex items-center gap-2 mb-2">
               <span className="text-3xl font-bold text-gray-900">{user.weight}</span>
               <span className="text-gray-500">kg</span>
             </div>
             <input 
              type="number" 
              placeholder="Novo peso (kg)"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-nutri-500 focus:ring-2 focus:ring-nutri-100 outline-none transition"
             />
             <button className="w-full py-3 text-sm font-medium text-white bg-nutri-500 hover:bg-nutri-600 rounded-xl transition shadow-md shadow-nutri-200">
                Atualizar Peso
             </button>
          </div>
        </div>

        {/* Water Tracker */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-2">Hidratação Diária</h3>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center border border-blue-100 relative">
              <Droplet size={24} fill="currentColor" className="z-10" />
              <div 
                className="absolute bottom-0 left-0 right-0 bg-blue-200 rounded-b-full transition-all duration-500"
                style={{ height: `${Math.min(100, (stats.waterConsumed / user.dailyWaterGoal) * 100)}%`, opacity: 0.5 }}
              />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {Math.round((stats.waterConsumed / user.dailyWaterGoal) * 100)}%
              </p>
              <p className="text-xs text-gray-500">{stats.waterConsumed} ml / {user.dailyWaterGoal} ml</p>
            </div>
          </div>

          <div className="flex items-center justify-between mb-4">
            <button 
              onClick={() => updateWater(-200)}
              className="w-10 h-10 flex items-center justify-center bg-gray-50 rounded-lg hover:bg-gray-100 text-gray-600 transition"
            >
              <Minus size={18} />
            </button>
            <div className="bg-white border border-gray-200 rounded-lg px-4 py-2 font-semibold text-gray-800 shadow-sm">
              200 ml
            </div>
            <button 
              onClick={() => updateWater(200)}
              className="w-10 h-10 flex items-center justify-center bg-nutri-500 rounded-lg hover:bg-nutri-600 text-white shadow-md shadow-nutri-200 transition"
            >
              <Plus size={18} />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-4">
            {[100, 200, 300, 500].map((amount) => (
              <button 
                key={amount}
                onClick={() => updateWater(amount)}
                className="py-1 text-[10px] bg-gray-50 hover:bg-nutri-50 hover:border-nutri-200 hover:text-nutri-600 rounded border border-gray-200 text-gray-600 transition-colors"
              >
                {amount}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;
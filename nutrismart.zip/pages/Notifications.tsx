import React, { useState } from 'react';
import { Bell, Droplet, Utensils, Dumbbell, Trophy } from 'lucide-react';

const Notifications: React.FC = () => {
  const [settings, setSettings] = useState({
    water: true,
    meals: true,
    workout: false,
    achievements: true,
    newsletter: false
  });

  const Toggle = ({ active, onClick }: { active: boolean; onClick: () => void }) => (
    <button 
      onClick={onClick}
      className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ${active ? 'bg-nutri-500' : 'bg-gray-200'}`}
    >
      <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform duration-300 ${active ? 'translate-x-6' : 'translate-x-0'}`} />
    </button>
  );

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Configurar Notificações</h1>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-lg flex items-center justify-center">
              <Droplet size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Lembrete de Água</h3>
              <p className="text-sm text-gray-500">Receba avisos a cada 2 horas</p>
            </div>
          </div>
          <Toggle active={settings.water} onClick={() => setSettings({...settings, water: !settings.water})} />
        </div>

        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-orange-50 text-orange-500 rounded-lg flex items-center justify-center">
              <Utensils size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Horário das Refeições</h3>
              <p className="text-sm text-gray-500">Avisos para Café, Almoço e Jantar</p>
            </div>
          </div>
          <Toggle active={settings.meals} onClick={() => setSettings({...settings, meals: !settings.meals})} />
        </div>

        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-red-50 text-red-500 rounded-lg flex items-center justify-center">
              <Dumbbell size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Lembrete de Treino</h3>
              <p className="text-sm text-gray-500">Motivação diária para se exercitar</p>
            </div>
          </div>
          <Toggle active={settings.workout} onClick={() => setSettings({...settings, workout: !settings.workout})} />
        </div>

        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-yellow-50 text-yellow-500 rounded-lg flex items-center justify-center">
              <Trophy size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Conquistas e Metas</h3>
              <p className="text-sm text-gray-500">Celebre quando bater suas metas</p>
            </div>
          </div>
          <Toggle active={settings.achievements} onClick={() => setSettings({...settings, achievements: !settings.achievements})} />
        </div>
      </div>
    </div>
  );
};

export default Notifications;
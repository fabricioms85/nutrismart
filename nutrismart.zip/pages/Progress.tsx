import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

// For demo purposes, we accept optional history, or default to mock data if empty
interface ProgressProps {
  weightHistory?: { day: string; weight: number }[];
  calorieHistory?: { day: string; calories: number }[];
}

const MOCK_WEIGHT_DATA = [
  { day: 'Seg', weight: 75.5 },
  { day: 'Ter', weight: 75.2 },
  { day: 'Qua', weight: 75.0 },
  { day: 'Qui', weight: 74.8 },
  { day: 'Sex', weight: 74.9 },
  { day: 'Sáb', weight: 74.5 },
  { day: 'Dom', weight: 74.2 },
];

const MOCK_CALORIE_DATA = [
  { day: 'Seg', calories: 2100 },
  { day: 'Ter', calories: 1950 },
  { day: 'Qua', calories: 2300 },
  { day: 'Qui', calories: 1800 },
  { day: 'Sex', calories: 2000 },
  { day: 'Sáb', calories: 2500 },
  { day: 'Dom', calories: 2100 },
];

const Progress: React.FC<ProgressProps> = ({ weightHistory, calorieHistory }) => {
  const finalWeightData = (weightHistory && weightHistory.length > 1) ? weightHistory : MOCK_WEIGHT_DATA;
  const finalCalorieData = (calorieHistory && calorieHistory.length > 1) ? calorieHistory : MOCK_CALORIE_DATA;

  const currentWeight = finalWeightData[finalWeightData.length - 1].weight;
  
  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Seu Progresso</h1>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Peso Atual</p>
          <div className="flex items-baseline gap-2">
            <h2 className="text-3xl font-bold text-gray-900">{currentWeight} <span className="text-sm font-normal text-gray-500">kg</span></h2>
            <span className="flex items-center text-sm font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
              <TrendingDown size={14} className="mr-1" /> -1.3kg
            </span>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Média Calórica (Semanal)</p>
          <div className="flex items-baseline gap-2">
            <h2 className="text-3xl font-bold text-gray-900">2,107 <span className="text-sm font-normal text-gray-500">kcal</span></h2>
            <span className="flex items-center text-sm font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
              <TrendingUp size={14} className="mr-1" /> Na meta
            </span>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Sequência de Registros</p>
          <div className="flex items-baseline gap-2">
            <h2 className="text-3xl font-bold text-gray-900">12 <span className="text-sm font-normal text-gray-500">dias</span></h2>
            <span className="flex items-center text-sm font-medium text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
              <TrendingUp size={14} className="mr-1" /> Recorde!
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Weight Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-6">Histórico de Peso</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={finalWeightData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} dy={10} />
                <YAxis domain={['dataMin - 1', 'dataMax + 1']} axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Line 
                  type="monotone" 
                  dataKey="weight" 
                  stroke="#00b37e" 
                  strokeWidth={3} 
                  dot={{fill: '#00b37e', strokeWidth: 2, r: 4, stroke: '#fff'}} 
                  activeDot={{r: 6}}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Calories Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-6">Consumo Calórico</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={finalCalorieData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <Tooltip 
                   cursor={{fill: '#f9fafb'}}
                   contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="calories" fill="#00b37e" radius={[6, 6, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Progress;
import { Achievement, DailyStats, Meal, Exercise, User } from "../types";

export const ACHIEVEMENT_DEFINITIONS: Achievement[] = [
  { 
    id: '1', 
    title: 'Primeiros Passos', 
    description: 'Registre sua primeira refeição no aplicativo', 
    iconName: 'Star', 
    unlocked: false 
  },
  { 
    id: '2', 
    title: 'Hidratação Mestre', 
    description: 'Beba 100% da sua meta de água diária', 
    iconName: 'Droplet', 
    unlocked: false 
  },
  { 
    id: '3', 
    title: 'Movimento Constante', 
    description: 'Realize pelo menos 3 exercícios registrados', 
    iconName: 'Flame', 
    unlocked: false 
  },
  { 
    id: '4', 
    title: 'Disciplina Diária', 
    description: 'Registre Café, Almoço e Jantar no mesmo dia', 
    iconName: 'Calendar', 
    unlocked: false 
  },
  { 
    id: '5', 
    title: 'Explorador', 
    description: 'Registre 5 refeições no total', 
    iconName: 'ChefHat', 
    unlocked: false 
  },
  { 
    id: '6', 
    title: 'Equilíbrio Perfeito', 
    description: 'Consuma exatamente (±50kcal) sua meta calórica', 
    iconName: 'Trophy', 
    unlocked: false 
  },
];

export const checkAchievements = (
  user: User, 
  stats: DailyStats, 
  allMeals: Meal[], 
  allExercises: Exercise[],
  existingUnlockedIds: string[]
): string[] => {
  const unlockedIds = new Set(existingUnlockedIds);

  // 1. Primeiros Passos
  if (allMeals.length > 0) {
    unlockedIds.add('1');
  }

  // 2. Hidratação
  if (stats.waterConsumed >= user.dailyWaterGoal && user.dailyWaterGoal > 0) {
    unlockedIds.add('2');
  }

  // 3. Movimento (Usando total de exercícios salvos)
  if (allExercises.length >= 3) {
    unlockedIds.add('3');
  }

  // 4. Disciplina (Verificar se hoje tem os 3 tipos principais)
  const todayMeals = allMeals.filter(m => {
    // Simplificação: Assume que allMeals são filtrados ou verificamos a data
    // No App.tsx atual, 'meals' parece ser a lista total. Vamos verificar tipos.
    // Para ser preciso, precisariamos filtrar por data. Como MVP, verificamos se existem no array atual.
    return true; 
  });
  
  const hasBreakfast = todayMeals.some(m => m.type === 'breakfast');
  const hasLunch = todayMeals.some(m => m.type === 'lunch');
  const hasDinner = todayMeals.some(m => m.type === 'dinner');
  
  if (hasBreakfast && hasLunch && hasDinner) {
    unlockedIds.add('4');
  }

  // 5. Explorador
  if (allMeals.length >= 5) {
    unlockedIds.add('5');
  }

  // 6. Equilíbrio
  const diff = Math.abs(user.dailyCalorieGoal - stats.caloriesConsumed);
  // Só desbloqueia se já tiver comido algo considerável (ex: > 1000kcal) para evitar desbloquear no começo do dia
  if (stats.caloriesConsumed > 1000 && diff <= 50) {
    unlockedIds.add('6');
  }

  return Array.from(unlockedIds);
};
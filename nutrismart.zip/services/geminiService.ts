import { GoogleGenAI, Type } from "@google/genai";
import { User, Recipe, DailyStats, Meal } from "../types";

// Initialize the client strictly according to guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface UserContext {
  user: User;
  stats: DailyStats;
  recentMeals: Meal[];
}

export const generateNutritionAdvice = async (prompt: string, context?: UserContext): Promise<string> => {
  try {
    let systemInstruction = "Você é um nutricionista especialista e motivador do aplicativo NutriSmart. Suas respostas devem ser curtas, encorajadoras e focadas em saúde e bem-estar. Responda sempre em Português do Brasil.";

    if (context) {
      const { user, stats, recentMeals } = context;
      const mealsSummary = recentMeals.map(m => `${m.name} (${m.calories}kcal)`).join(', ');
      
      systemInstruction += `
      
      DADOS DO USUÁRIO ATUAL (Use isso para personalizar a resposta):
      - Nome: ${user.name}
      - Objetivo: ${user.goal || 'Saúde Geral'}
      - Meta Calórica Diária: ${user.dailyCalorieGoal} kcal
      - Consumo Hoje: ${stats.caloriesConsumed} kcal (Restam: ${user.dailyCalorieGoal - stats.caloriesConsumed} kcal)
      - Água Hoje: ${stats.waterConsumed}ml / ${user.dailyWaterGoal}ml
      - Refeições de hoje: ${mealsSummary || 'Nenhuma registrada ainda'}
      
      Se o usuário perguntar "o que posso comer", sugira algo que caiba nas calorias restantes.
      Se o usuário perguntar sobre seu progresso, use os números acima.
      `;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text || "Desculpe, não consegui processar sua solicitação no momento.";
  } catch (error) {
    console.error("Erro ao consultar Gemini:", error);
    return "Ocorreu um erro ao conectar com o assistente inteligente. Tente novamente mais tarde.";
  }
};

export const analyzeFoodImage = async (base64Data: string, mimeType: string = 'image/jpeg'): Promise<{
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  weight: number;
  ingredients: { name: string; quantity: string; unit: string }[];
} | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data
            }
          },
          {
            text: 'Analise esta imagem de comida. Identifique o prato principal, estime os ingredientes visíveis com suas quantidades aproximadas e calcule os valores nutricionais totais.'
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: "Nome curto e descritivo do prato em Português" },
            calories: { type: Type.NUMBER, description: "Estimativa de calorias totais (kcal)" },
            protein: { type: Type.NUMBER, description: "Proteínas totais em gramas" },
            carbs: { type: Type.NUMBER, description: "Carboidratos totais em gramas" },
            fats: { type: Type.NUMBER, description: "Gorduras totais em gramas" },
            weight: { type: Type.NUMBER, description: "Estimativa do peso total da porção em gramas" },
            ingredients: {
              type: Type.ARRAY,
              description: "Lista estimada de ingredientes que compõem o prato",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  quantity: { type: Type.STRING, description: "Número em formato string (ex: '100', '1')" },
                  unit: { type: Type.STRING, description: "Unidade (g, ml, colher, unidade, fatia)" }
                },
                required: ["name", "quantity", "unit"]
              }
            }
          },
          required: ["name", "calories", "protein", "carbs", "fats", "weight", "ingredients"],
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return null;
  } catch (error) {
    console.error("Erro na análise de imagem:", error);
    throw error;
  }
};

export const calculateNutritionalInfo = async (foodItems: {name: string, quantity: string, unit: string}[]): Promise<{
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
} | null> => {
  try {
    const itemsDescription = foodItems.map(f => `${f.quantity}${f.unit} de ${f.name}`).join(', ');
    const prompt = `Calcule o total nutricional aproximado para a seguinte lista de alimentos: ${itemsDescription}. Retorne o total somado.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            calories: { type: Type.NUMBER },
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fats: { type: Type.NUMBER },
          },
          required: ["calories", "protein", "carbs", "fats"],
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return null;
  } catch (error) {
    console.error("Erro ao calcular nutrientes:", error);
    throw error;
  }
};

export const generateWeeklyMealPlan = async (user: User): Promise<any> => {
  try {
    const prompt = `Crie um plano alimentar de 1 dia (exemplo) baseado nestes dados: 
    Meta de calorias: ${user.dailyCalorieGoal}, Objetivo: ${user.goal || 'Saúde'}.
    Retorne apenas um array JSON com 4 refeições (Café, Almoço, Lanche, Jantar).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            meals: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, enum: ["Café da Manhã", "Almoço", "Lanche", "Jantar"] },
                  name: { type: Type.STRING },
                  calories: { type: Type.NUMBER },
                }
              }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text).meals;
    }
    return [];
  } catch (error) {
    console.error("Erro ao gerar plano:", error);
    return [];
  }
};

export const generateSmartRecipes = async (ingredients: string): Promise<Omit<Recipe, 'id' | 'image'>[]> => {
  try {
    const prompt = `Eu tenho os seguintes ingredientes: ${ingredients}. 
    Sugira 3 receitas criativas e saudáveis que posso fazer com eles (assuma que tenho básicos como sal, óleo, água).
    Retorne um JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recipes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  calories: { type: Type.NUMBER },
                  timeMinutes: { type: Type.NUMBER },
                  difficulty: { type: Type.STRING, enum: ['Fácil', 'Médio', 'Difícil'] },
                  tags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  englishSearchTerm: { type: Type.STRING, description: "A simple english term to search for an image of this food (e.g. 'chicken salad', 'pasta')" }
                },
                required: ["title", "calories", "timeMinutes", "difficulty", "tags", "englishSearchTerm"]
              }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text).recipes;
    }
    return [];
  } catch (error) {
    console.error("Erro ao gerar receitas:", error);
    throw error;
  }
};